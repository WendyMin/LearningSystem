import React from 'react';
import makeWindow from 'HOC/makeWindow';
var id = 0;
var __props;
export default makeWindow( ( props ) => { __props = props; return (<span>{props.info}</span>)} , np => { if( np.info !== __props.info ){ __props.info = np.info ; return true } return false } )
