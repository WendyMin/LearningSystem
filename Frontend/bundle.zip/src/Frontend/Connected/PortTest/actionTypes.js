export const __ASYNC_LOAD_PORT_CONTENT = {
  pending: "PortContent/__LOAD_WRITE_CONTENTS_PENDING",
  resolved: "PortContent/__LOAD_WRITE_CONTENTS_RESOLVED",
  rejected: "PortContent/__LOAD_WRITE_CONTENTS_REJECTED"
};
