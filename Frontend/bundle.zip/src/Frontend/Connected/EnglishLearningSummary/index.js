import view from 'layout';
export { view };
