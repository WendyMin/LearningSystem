export const LOGIN = {
  pending: 'USER/START_LOGIN',
  resolved: 'USER/LOGIN_SUCC',
  rejected: 'USER/LOGIN_FAILED'
};
