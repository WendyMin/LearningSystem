export const __ASYNC_LOAD_WRITE_CONTENTS = {
  pending: "WriteContent/__LOAD_WRITE_CONTENTS_PENDING",
  resolved: "ButtonExpand/__LOAD_WRITE_CONTENTS_RESOLVED",
  rejected: "ButtonExpand/__LOAD_WRITE_CONTENTS_REJECTED"
};
