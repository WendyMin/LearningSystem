export default {
  UserManager: {
    //logined: false,
    logined: true,
    name: "testdzh",
    password: "testdzh",
    newTo: [ 0 , 1 , 0 , 0]
  }
}
