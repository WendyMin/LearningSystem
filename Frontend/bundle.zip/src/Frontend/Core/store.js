import logger from "redux-logger";
import thunk from "redux-thunk";
export default {
  middleWares: [ logger , thunk ]
} ;
