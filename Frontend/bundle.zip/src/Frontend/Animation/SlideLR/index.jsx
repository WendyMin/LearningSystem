import makeAnimation from 'direct-core/makeAnimation';
import slideLR from 'style';

const timeout = {
  enter: 1000,
  exit: 1000
};

export default makeAnimation( slideLR , timeout );
