import makeAnimation from 'direct-core/makeAnimation';
import slideRL from 'style';

const timeout = {
  enter: 1000,
  exit: 1000
};

export default makeAnimation( slideRL , timeout );
